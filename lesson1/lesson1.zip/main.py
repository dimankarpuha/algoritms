import numpy as np
arr = np.random.randint(4,100,5)
print(arr)
